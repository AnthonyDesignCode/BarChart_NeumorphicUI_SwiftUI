//
//  ContentView.swift
//  BarChart_Neumorphic_SwiftUI
//
//  Created by Immature Inc on 20/05/2020.
//  Copyright © 2020 AnthonyDesignCode.io. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            //Create the Background
            Rectangle()
                .fill(Color("Background"))
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .edgesIgnoringSafeArea(.all)
            //Add BarChart
            HStack(alignment: .bottom, spacing: 20) {
                ForEach(percents){i in
                    Bar(percent: i.percent,day: i.day)
                }
            }
            .frame(height: 250)
            .padding()
            //Add the title
            VStack(spacing: 40) {
                Text("Bar Chart")
                    .font(.system(size: 45, weight: .heavy, design: .rounded))
                    .foregroundColor(Color("card1"))
                    .padding(.top, 290)
                    .shadow(color: Color("LightShadow"), radius: 8, x: -8, y: -8)
                    .shadow(color: Color("DarkShadow"), radius: 8, x: 8, y: 8)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Bar: View {
    
    var percent : CGFloat = 0
    var day = ""
            
    var body: some View {
        ZStack (alignment: .bottom) {
            Capsule()
                .fill(Color("Background"))
                .frame(width: 50, height: 200)
                .shadow(color: Color("LightShadow"), radius: 8, x: -8, y: -8)
                .shadow(color: Color("DarkShadow"), radius: 8, x: 8, y: 8)
                                
            Capsule()
                .fill(LinearGradient(gradient: Gradient(colors: [Color("card1"), Color("card2")]), startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: UIScreen.main.bounds.width / 7 - 12, height: getHeight())
        }
    }
    func getHeight()->CGFloat {
        return 200 / 100 * percent
        
    }
}

struct type: Identifiable {
    var id : Int
    var percent : CGFloat
    var day : String
}

var percents = [
    type(id: 0, percent: 90, day: "Mon"),
    type(id: 1, percent: 55, day: "Tue"),
    type(id: 2, percent: 75, day: "Wed")
]

